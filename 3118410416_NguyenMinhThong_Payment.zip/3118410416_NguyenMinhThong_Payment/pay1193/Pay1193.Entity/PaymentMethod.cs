﻿namespace Pay1193.Entity
{
    public enum PaymentMethod
    {
        Bank,
        Cash,
        Check
    }
}