﻿namespace Pay1193.Entity
{
    public enum UnionMember
    {
        No,
        Yes
    }
}